const express = require('express');
const app = express();
const db = require('./config/db');
const ordersRouter = require('./routes/orders');

app.use(express.json());
app.use('/orders', ordersRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
