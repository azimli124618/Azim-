const express = require('express');
const router = express.Router();

// Sipariş rotaları burada
router.get('/', (req, res) => {
    res.send('Order listesi');
});

module.exports = router;
