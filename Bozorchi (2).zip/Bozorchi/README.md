# Bozorchi

Bozorchi pazardan eve teslimat sisteminin temel yapısı.

## Kurulum

- Backend: `cd backend && npm install && npm start-backend`
- Frontend: `cd frontend && npm install && npm start-frontend`
- Telegram Bot: `cd telegram-bot && npm install && npm start-bot`

## Özellikler

- Sipariş yönetimi
- Ürün ve kategori yönetimi
- Telegram bot entegrasyonu
