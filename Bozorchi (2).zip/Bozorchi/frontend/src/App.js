import React from 'react';

function App() {
  return <h1>Bozorchi Ana Sayfa</h1>;
}

export default App;
